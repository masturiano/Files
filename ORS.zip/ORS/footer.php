<div class="navbar navbar-inverse nav">
    <div class="navbar-inner">
        <div class="container">
        	<a class="brand" href="#"><font size="-1">&copy; 2013 Puregold Price Club Inc.</font></a>
        </div>
    </div>
</div>